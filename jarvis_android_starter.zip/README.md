# JARVIS Android Starter

A lightweight Android-friendly JARVIS-style web app with a futuristic animated orb, voice input/output, and an optional Python AI backend.

## What works in this starter
- Mobile-first interface that can be added to the Android home screen.
- Voice input through the browser Web Speech API (best effort; browser/device support varies).
- Spoken replies using browser speech synthesis.
- Animated CSS orb / sci-fi HUD styling (3D-style visual, not a real 3D scene).
- Local fallback responses when no backend is configured.
- Optional FastAPI backend. API keys are read from environment variables and never belong in frontend code.

## Quick start on Android
The easiest route is to run the frontend locally on a computer on the same Wi-Fi, then open it on Android Chrome. For mic permissions and reliable PWA installation, HTTPS is recommended when hosted publicly.

### Frontend-only demo
1. Unzip this folder.
2. Open `frontend/index.html` in a modern browser for a basic demo. Voice recognition may not work from `file://`.
3. For a local web server from the project root:
   ```bash
   cd frontend
   python -m http.server 8000
   ```
4. On the same Wi-Fi, find your computer's LAN IP and open `http://COMPUTER_IP:8000` on the phone.
   Microphone APIs may require HTTPS or localhost; if voice input is blocked, deploy on an HTTPS host or use Android Chrome with a supported secure origin.

### Optional AI backend
Requires Python 3.10+.

1. In a terminal:
   ```bash
   cd backend
   python -m venv .venv
   # Windows: .venv\\Scripts\\activate
   # macOS/Linux: source .venv/bin/activate
   pip install -r requirements.txt
   ```
2. Set environment variables in the terminal (do not put secrets in HTML/JS):
   ```bash
   # Linux/macOS
   export AI_API_KEY="your_key_here"
   export AI_BASE_URL="https://api.openai.com/v1"
   export AI_MODEL="gpt-4o-mini"
   ```
   PowerShell:
   ```powershell
   $env:AI_API_KEY="your_key_here"
   $env:AI_BASE_URL="https://api.openai.com/v1"
   $env:AI_MODEL="gpt-4o-mini"
   ```
3. Start the API:
   ```bash
   uvicorn app:app --host 0.0.0.0 --port 8001
   ```
4. Serve the frontend from a web server and configure `frontend/app.js`'s `API_URL` to your backend address. For local Wi-Fi, use `http://COMPUTER_IP:8001`; public deployment should use HTTPS and a protected backend.
5. Never expose the API key in browser JavaScript, a public repository, or a mobile app bundle.

## Android home-screen install
Host the frontend on an HTTPS static host, open the site in Chrome on Android, open the browser menu, and choose **Add to Home screen** / **Install app** if offered.

## Test checklist
- [ ] Open the app; orb and chat UI render.
- [ ] Type `hello` and confirm a reply appears.
- [ ] Tap the mic and grant microphone permission; speak a short phrase.
- [ ] Tap Speak / enable voice replies and confirm the phone reads replies aloud.
- [ ] If backend enabled, open `http://BACKEND_HOST:8001/health` and confirm `{"status":"ok"}`.
- [ ] Test invalid backend URL / network loss; frontend should show a useful error or use local fallback.
- [ ] Verify API key is set only in backend environment variables.

## Current limitations
This is a starter prototype, not the movie JARVIS. It does not control Android settings or other apps automatically. Browser speech support depends on the browser/device, the backend needs internet access and a provider API key, and the CSS orb is a visual effect rather than a true 3D model.
