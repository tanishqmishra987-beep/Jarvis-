import os
from typing import Optional

import httpx
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

app = FastAPI(title="JARVIS Starter API", version="0.1.0")

# For a public deployment, restrict allow_origins to your exact HTTPS frontend domain.
# This permissive list is intended only for local prototype testing.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=8000)

class ChatResponse(BaseModel):
    reply: str

@app.get("/health")
async def health():
    return {"status": "ok", "provider_configured": bool(os.getenv("AI_API_KEY"))}

@app.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    api_key = os.getenv("AI_API_KEY")
    if not api_key:
        raise HTTPException(status_code=503, detail="AI_API_KEY is not configured on the backend.")

    base_url = os.getenv("AI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
    model = os.getenv("AI_MODEL", "gpt-4o-mini")
    system_prompt = (
        "You are JARVIS, a helpful, calm personal assistant. Be clear and concise. "
        "Do not claim to control devices or perform actions unless a connected tool actually did so."
    )
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": request.message},
        ],
        "temperature": 0.6,
    }
    try:
        async with httpx.AsyncClient(timeout=45.0) as client:
            response = await client.post(
                f"{base_url}/chat/completions",
                headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
                json=payload,
            )
        if response.status_code >= 400:
            # Do not return provider response bodies because they can contain sensitive diagnostics.
            raise HTTPException(status_code=502, detail=f"AI provider request failed (HTTP {response.status_code}).")
        data = response.json()
        reply: Optional[str] = data.get("choices", [{}])[0].get("message", {}).get("content")
        if not reply:
            raise HTTPException(status_code=502, detail="AI provider returned an empty response.")
        return ChatResponse(reply=reply)
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="AI provider timed out.")
    except httpx.RequestError:
        raise HTTPException(status_code=502, detail="Could not reach AI provider.")
