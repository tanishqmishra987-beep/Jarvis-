// JARVIS starter frontend. No secret keys belong in this file.
const API_URL = ""; // Optional: e.g. "http://192.168.1.20:8001/chat" for local testing.
const messagesEl = document.getElementById("messages");
const form = document.getElementById("chatForm");
const input = document.getElementById("messageInput");
const micButton = document.getElementById("micButton");
const voiceReplies = document.getElementById("voiceReplies");
const statusText = document.getElementById("statusText");
const subtitle = document.getElementById("subtitle");
const notice = document.getElementById("notice");
const orbWrap = document.getElementById("orbWrap");
let recognition = null;
let listening = false;

function addMessage(text, who = "assistant") {
  const article = document.createElement("article");
  article.className = `message ${who}`;
  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.textContent = who === "assistant" ? "J" : "YOU";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  const sender = document.createElement("div");
  sender.className = "sender";
  sender.textContent = who === "assistant" ? "JARVIS" : "YOU";
  const time = document.createElement("time");
  time.textContent = new Date().toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"});
  sender.appendChild(time);
  const p = document.createElement("p");
  p.textContent = text; // textContent prevents HTML injection.
  bubble.append(sender, p);
  article.append(avatar, bubble);
  messagesEl.appendChild(article);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function speak(text) {
  if (!voiceReplies.checked || !("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "en-IN";
  utterance.rate = 1;
  window.speechSynthesis.speak(utterance);
}

function localReply(message) {
  const m = message.toLowerCase().trim();
  if (/^(hi|hello|hey|namaste|namaskar)\b/.test(m)) return "Hello. JARVIS is online. What would you like to work on?";
  if (m.includes("time")) return `Your device time is ${new Date().toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"})}.`;
  if (m.includes("date") || m.includes("today")) return `Today is ${new Date().toLocaleDateString(undefined, {weekday:"long", year:"numeric", month:"long", day:"numeric"})}.`;
  if (m.includes("who are you") || m.includes("your name")) return "I’m your JARVIS-style assistant prototype. Connect the optional backend to enable AI-generated replies.";
  if (m.includes("help")) return "Try asking for the time, today's date, or connect the optional backend for general AI conversation.";
  return "I received your message. This starter is running in local demo mode, so its replies are limited. Connect the optional AI backend for richer answers.";
}

async function getReply(message) {
  if (!API_URL) return localReply(message);
  try {
    const response = await fetch(API_URL, {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({message})
    });
    if (!response.ok) throw new Error(`Backend returned ${response.status}`);
    const data = await response.json();
    if (!data.reply) throw new Error("Backend response did not include a reply");
    return data.reply;
  } catch (error) {
    notice.textContent = `AI backend unavailable (${error.message}). Using local demo replies.`;
    return localReply(message);
  }
}

async function sendMessage(message) {
  const cleaned = message.trim();
  if (!cleaned) return;
  addMessage(cleaned, "user");
  input.value = "";
  statusText.textContent = "PROCESSING";
  subtitle.textContent = "Processing your request...";
  orbWrap.classList.add("working");
  const reply = await getReply(cleaned);
  addMessage(reply, "assistant");
  speak(reply);
  statusText.textContent = "SYSTEM ONLINE";
  subtitle.textContent = "Voice interface initialized. What can I do for you?";
  orbWrap.classList.remove("working");
}

form.addEventListener("submit", event => {
  event.preventDefault();
  sendMessage(input.value);
});

document.getElementById("clearButton").addEventListener("click", () => {
  messagesEl.replaceChildren();
  addMessage("Conversation cleared. I’m ready for a new request.");
});

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
if (SpeechRecognition) {
  recognition = new SpeechRecognition();
  recognition.lang = "en-IN";
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;
  recognition.onstart = () => {
    listening = true;
    micButton.classList.add("listening");
    statusText.textContent = "LISTENING";
    subtitle.textContent = "I’m listening...";
  };
  recognition.onresult = event => {
    const transcript = event.results[0][0].transcript;
    input.value = transcript;
    sendMessage(transcript);
  };
  recognition.onerror = event => {
    notice.textContent = `Voice input error: ${event.error}. Check microphone permission and browser support.`;
  };
  recognition.onend = () => {
    listening = false;
    micButton.classList.remove("listening");
    statusText.textContent = "SYSTEM ONLINE";
    subtitle.textContent = "Voice interface initialized. What can I do for you?";
  };
  micButton.addEventListener("click", () => {
    if (listening) recognition.stop();
    else {
      try { recognition.start(); }
      catch (_) { notice.textContent = "Voice input is busy. Wait a moment and try again."; }
    }
  });
} else {
  micButton.disabled = true;
  micButton.style.opacity = ".45";
  notice.textContent = "This browser does not support speech recognition. Try current Chrome on Android, or type messages instead.";
  micButton.addEventListener("click", () => {});
}

if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => navigator.serviceWorker.register("sw.js").catch(() => {}));
}
